'use client';

import React from 'react';
import { useSlideshowContext } from '@/context/slideshow-context';
import type { Annotation, AnnotationType } from '@/types';
import { useToast } from '@/hooks/use-toast';

export function SlideEditor() {
  const { toast } = useToast();
  const {
    currentSlideshow,
    currentSlideIndex,
    addAnnotation,
    updateAnnotation,
    deleteAnnotation
  } = useSlideshowContext();

  const [selectedAnnotation, setSelectedAnnotation] = React.useState<Annotation | null>(null);
  const [isDragging, setIsDragging] = React.useState(false);
  const [dragOffset, setDragOffset] = React.useState({ x: 0, y: 0 });
  const [isResizing, setIsResizing] = React.useState(false);
  const [resizeDirection, setResizeDirection] = React.useState('');
  const [selectedTool, setSelectedTool] = React.useState<AnnotationType | null>(null);
  const editorRef = React.useRef<HTMLDivElement>(null);

  // Listen for key events to delete the selected annotation
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Delete' && selectedAnnotation) {
        deleteAnnotation(selectedAnnotation.id);
        setSelectedAnnotation(null);

        toast({
          title: "Annotation deleted",
          description: "The annotation has been removed from the slide."
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [deleteAnnotation, selectedAnnotation, toast]);

  // Subscribe to tool changes from the ToolPanel
  React.useEffect(() => {
    // This would be replaced with a proper event system or context in a real app
    const handleToolChange = (e: CustomEvent) => {
      setSelectedTool(e.detail.tool);
    };

    window.addEventListener('tool-change' as any, handleToolChange);
    return () => window.removeEventListener('tool-change' as any, handleToolChange);
  }, []);

  if (!currentSlideshow || currentSlideIndex >= currentSlideshow.slides.length) {
    return <div className="text-center p-8 text-gray-500">No slide selected</div>;
  }

  const currentSlide = currentSlideshow.slides[currentSlideIndex];

  const handleEditorClick = (e: React.MouseEvent) => {
    // Only handle clicks directly on the editor (not on annotations)
    if (e.target === editorRef.current) {
      // If a tool is selected, add the annotation
      if (selectedTool) {
        const rect = editorRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        addAnnotation(selectedTool, x, y);

        // Clear the selected tool after adding
        setSelectedTool(null);

        // Notify ToolPanel (would be replaced with a proper event system or context)
        window.dispatchEvent(new CustomEvent('annotation-added', {
          detail: { type: selectedTool }
        }));
      }

      setSelectedAnnotation(null);
    }
  };

  const handleAnnotationClick = (e: React.MouseEvent, annotation: Annotation) => {
    e.stopPropagation();
    setSelectedAnnotation(annotation);
  };

  const handleAnnotationDragStart = (e: React.MouseEvent, annotation: Annotation) => {
    e.stopPropagation();
    setSelectedAnnotation(annotation);
    setIsDragging(true);

    // Calculate the offset from the mouse position to the top-left corner of the annotation
    const rect = (e.target as HTMLElement).getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !selectedAnnotation || !editorRef.current) return;

    const editorRect = editorRef.current.getBoundingClientRect();
    const newX = e.clientX - editorRect.left - dragOffset.x;
    const newY = e.clientY - editorRect.top - dragOffset.y;

    // Update the annotation position
    const updatedAnnotation = {
      ...selectedAnnotation,
      x: Math.max(0, newX),
      y: Math.max(0, newY)
    };

    updateAnnotation(updatedAnnotation);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
  };

  const handleDeleteAnnotation = () => {
    if (!selectedAnnotation) return;

    deleteAnnotation(selectedAnnotation.id);
    setSelectedAnnotation(null);

    toast({
      title: "Annotation deleted",
      description: "The annotation has been removed from the slide."
    });
  };

  const handleResizeStart = (e: React.MouseEvent, direction: string) => {
    e.stopPropagation();
    if (!selectedAnnotation) return;

    setIsResizing(true);
    setResizeDirection(direction);
  };

  const renderAnnotations = () => {
    return currentSlide.annotations.map((annotation) => {
      const isSelected = selectedAnnotation?.id === annotation.id;

      switch (annotation.type) {
        case 'text':
          return (
            <div
              key={annotation.id}
              className={`absolute cursor-move ${isSelected ? 'ring-2 ring-blue-500' : ''}`}
              style={{
                left: `${annotation.x}px`,
                top: `${annotation.y}px`,
                width: `${annotation.width}px`,
                height: `${annotation.height}px`,
                transform: `rotate(${annotation.rotation}deg)`,
                color: annotation.color,
                fontSize: `${annotation.fontSize}px`,
                padding: '4px',
              }}
              onClick={(e) => handleAnnotationClick(e, annotation)}
              onMouseDown={(e) => handleAnnotationDragStart(e, annotation)}
            >
              {annotation.content}

              {isSelected && (
                <div className="absolute -top-3 -left-3 -right-3 -bottom-3 border-2 border-blue-500 border-dashed pointer-events-none" />
              )}

              {isSelected && (
                <>
                  <div
                    className="absolute w-3 h-3 bg-white border border-blue-500 -right-1.5 -bottom-1.5 cursor-se-resize"
                    onMouseDown={(e) => handleResizeStart(e, 'se')}
                  />
                  <div
                    className="absolute w-3 h-3 bg-white border border-blue-500 -right-1.5 top-1/2 -mt-1.5 cursor-e-resize"
                    onMouseDown={(e) => handleResizeStart(e, 'e')}
                  />
                  <div
                    className="absolute w-3 h-3 bg-white border border-blue-500 left-1/2 -bottom-1.5 -ml-1.5 cursor-s-resize"
                    onMouseDown={(e) => handleResizeStart(e, 's')}
                  />
                </>
              )}
            </div>
          );
        case 'highlight':
          return (
            <div
              key={annotation.id}
              className={`absolute cursor-move ${isSelected ? 'ring-2 ring-blue-500' : ''}`}
              style={{
                left: `${annotation.x}px`,
                top: `${annotation.y}px`,
                width: `${annotation.width}px`,
                height: `${annotation.height}px`,
                backgroundColor: annotation.color,
                opacity: 0.3,
                transform: `rotate(${annotation.rotation}deg)`,
              }}
              onClick={(e) => handleAnnotationClick(e, annotation)}
              onMouseDown={(e) => handleAnnotationDragStart(e, annotation)}
            >
              {isSelected && (
                <div className="absolute -top-3 -left-3 -right-3 -bottom-3 border-2 border-blue-500 border-dashed pointer-events-none" />
              )}

              {isSelected && (
                <>
                  <div
                    className="absolute w-3 h-3 bg-white border border-blue-500 -right-1.5 -bottom-1.5 cursor-se-resize"
                    onMouseDown={(e) => handleResizeStart(e, 'se')}
                  />
                  <div
                    className="absolute w-3 h-3 bg-white border border-blue-500 -right-1.5 top-1/2 -mt-1.5 cursor-e-resize"
                    onMouseDown={(e) => handleResizeStart(e, 'e')}
                  />
                  <div
                    className="absolute w-3 h-3 bg-white border border-blue-500 left-1/2 -bottom-1.5 -ml-1.5 cursor-s-resize"
                    onMouseDown={(e) => handleResizeStart(e, 's')}
                  />
                </>
              )}
            </div>
          );
        case 'arrow': {
          const arrowPoints = annotation.arrowPoints;
          if (!arrowPoints) return null;

          return (
            <div
              key={annotation.id}
              className="absolute top-0 left-0 w-full h-full"
              onClick={(e) => handleAnnotationClick(e, annotation)}
            >
              <svg
                className="absolute top-0 left-0 w-full h-full"
                style={{
                  pointerEvents: 'none',
                }}
              >
                <defs>
                  <marker
                    id={`arrowhead-${annotation.id}`}
                    markerWidth="10"
                    markerHeight="7"
                    refX="9"
                    refY="3.5"
                    orient="auto"
                  >
                    <polygon
                      points="0 0, 10 3.5, 0 7"
                      fill={annotation.color}
                    />
                  </marker>
                </defs>
                <line
                  x1={arrowPoints.x1}
                  y1={arrowPoints.y1}
                  x2={arrowPoints.x2}
                  y2={arrowPoints.y2}
                  stroke={annotation.color}
                  strokeWidth="2"
                  markerEnd={`url(#arrowhead-${annotation.id})`}
                />
              </svg>

              {isSelected && (
                <>
                  <div
                    className="absolute w-4 h-4 bg-white border border-blue-500 rounded-full cursor-move"
                    style={{
                      left: `${arrowPoints.x1 - 2}px`,
                      top: `${arrowPoints.y1 - 2}px`,
                    }}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      setIsDragging(true);
                      setSelectedAnnotation(annotation);
                      setResizeDirection('start');
                    }}
                  />
                  <div
                    className="absolute w-4 h-4 bg-white border border-blue-500 rounded-full cursor-move"
                    style={{
                      left: `${arrowPoints.x2 - 2}px`,
                      top: `${arrowPoints.y2 - 2}px`,
                    }}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      setIsDragging(true);
                      setSelectedAnnotation(annotation);
                      setResizeDirection('end');
                    }}
                  />
                </>
              )}
            </div>
          );
        }
        default:
          return null;
      }
    });
  };

  return (
    <div
      className={`relative w-full h-full max-w-6xl max-h-[80vh] bg-white shadow-lg ${selectedTool ? 'cursor-crosshair' : 'cursor-default'}`}
      style={{
        backgroundColor: currentSlide.backgroundColor,
        backgroundImage: currentSlide.backgroundImage ? `url(${currentSlide.backgroundImage})` : 'none',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
      ref={editorRef}
      onClick={handleEditorClick}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {renderAnnotations()}

      {selectedTool && (
        <div className="absolute top-4 left-4 bg-black bg-opacity-75 text-white px-3 py-1 rounded text-sm">
          Click to add {selectedTool}
        </div>
      )}
    </div>
  );
}
